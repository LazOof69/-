package com.example.myapplication.ui.theme

interface ＭyapplicationTheme {

}
