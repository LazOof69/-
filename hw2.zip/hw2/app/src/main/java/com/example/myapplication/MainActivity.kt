package com.example.myapplication

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Menu
import androidx.compose.material3.ElevatedButton
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.TopAppBar
import androidx.compose.ui.Alignment
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.sp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.Image
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material.icons.filled.ArrowBack
import androidx.navigation.NavType
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.navArgument
import android.content.Intent
import android.net.Uri
import androidx.compose.ui.platform.LocalContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            val navController = rememberNavController()
            MyApp(navController = navController)
        }
    }
}
enum class MainScreen() {
    Start,
    ShowMore
}
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter", "ComposableDestinationInComposeScope")
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MyApp(
    navController: NavHostController = rememberNavController()
) {
    val names = listOf(
        "國立中正紀念堂",
        "國立故宮博物院",
        "台北101",
        "三峽老街",
        "臺中國家歌劇院",
        "安平古堡",
        "高雄85大樓",
        "日月潭",
        "鵝鑾鼻燈塔",
        "墾丁白沙灣"
    )
    val currentRoute = navController.currentBackStackEntryAsState().value?.destination?.route
    val showBackIcon = currentRoute != MainScreen.Start.name
    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("台灣景點推薦") },
                navigationIcon = {
                    if (showBackIcon) {
                        IconButton(onClick = { navController.navigateUp() }) {
                            Icon(Icons.Default.ArrowBack, contentDescription = "back")
                        }
                    } else {
                        IconButton(onClick = { /* Handle menu icon click */ }) {
                            Icon(Icons.Default.Menu, contentDescription = "Menu")
                        }
                    }
                }
            )
        }
    ) { innerPadding ->
        NavHost(navController = navController, startDestination = MainScreen.Start.name, modifier = Modifier.padding(innerPadding)) {
            composable(route = MainScreen.Start.name) {
                StartItem(names = names) { index ->
                    navController.navigate("${MainScreen.ShowMore.name}/$index")
                }
            }
            composable(
                route = "${MainScreen.ShowMore.name}/{index}",
                arguments = listOf(navArgument("index") { type = NavType.IntType })
            ) { backStackEntry ->
                val index = backStackEntry.arguments?.getInt("index") ?: 0
                val name = names.getOrNull(index) ?: ""
                ShowMoreScreen(index = index, name = name, navigateUp = { navController.navigateUp() })
            }
        }
    }
}


@Composable
fun StartItem(
    modifier: Modifier = Modifier,
    names: List<String> = List(10) { "$it" },
    navigateToShowMore: (Int) -> Unit
) {
    LazyColumn(modifier = modifier.padding(vertical = 4.dp)) {
        itemsIndexed(items = names) { index, name ->
            StartScreen(name = name, index = index, navigateToShowMore = navigateToShowMore)
        }
    }
}

@Composable
fun StartScreen(
    modifier: Modifier = Modifier,
    name: String,
    index: Int,
    navigateToShowMore: (Int) -> Unit
) {
    Surface(
        color = MaterialTheme.colorScheme.primary,
        modifier = modifier.padding(vertical = 4.dp, horizontal = 8.dp)
    ) {
        Row(modifier = Modifier.padding(24.dp)) {
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = name,
                    fontSize = 20.sp
                )
            }
            ElevatedButton(
                onClick = { navigateToShowMore(index) }
            ) {
                Text(
                    "Show More",
                    fontSize = 14.sp
                )
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@SuppressLint("UnusedMaterial3ScaffoldPaddingParameter")
@Composable
fun ShowMoreScreen(
    index: Int,
    name: String,
    navigateUp: () -> Unit
){
    val context = LocalContext.current
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        val image = painterResource(Picture(index+1))
        Image(
            painter = image,
            contentDescription = null,
            modifier = Modifier.size(200.dp)
        )
        Text(
            text = Introduce(index+1),
            fontSize = 12.sp,
            textAlign = TextAlign.Left,
            modifier = Modifier.padding(horizontal = 16.dp)
        )
        ElevatedButton(
            onClick = {
                val url = "https://www.google.com/maps/search/?api=1&query=${Uri.encode(name)}"
                val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                context.startActivity(intent)
            }
        ) {
            Text(
                "Google Map",
                fontSize = 14.sp
            )
        }
    }
}

@Composable
fun Picture(index: Int): Int {
    return when (index) {
        1 -> R.drawable.pic1
        2 -> R.drawable.pic2
        3 -> R.drawable.pic3
        4 -> R.drawable.pic4
        5 -> R.drawable.pic5
        6 -> R.drawable.pic6
        7 -> R.drawable.pic7
        8 -> R.drawable.pic8
        9 -> R.drawable.pic9
        10 -> R.drawable.pic10
        else -> R.drawable.ic_launcher_foreground
    }
}
@Composable
fun Introduce(index: Int): String{
    return when (index) {
        1 -> "中正紀念堂是位於中華民國臺北市中正區的國家紀念建築，是中華民國政府為紀念已故前總統蔣中正而興建，為眾多紀念蔣中正的建築中規模最大者，管理機關為中華民國文化部轄下的「國立中正紀念堂管理處」。"
        2 -> "國立故宮博物院，簡稱臺灣故宮或臺北故宮，別名中山博物院，為臺灣最具規模的博物館以及臺灣八景之一，也是古代中國藝術史與漢學研究機構。館舍分別位於臺北市士林區與嘉義縣太保市，一年接待超過614萬人次的參訪旅客，曾位列2015年全球參觀人數第六多的藝術博物館。"
        3 -> "台北101是位於臺灣臺北市信義計畫區的超高層摩天大樓，樓高508公尺，地上101層、地下5層。於2004年12月31日落成至2010年1月4日是世界第一高樓。目前是台灣第一高樓，以及臺灣唯一高度超過500公尺、樓層超過100層的建築物。"
        4 -> "以金牛角著名的三峽老街，又稱三角涌老街，自清朝以來即為繁榮的商業大街，日治時期經街道整頓後，新洋樓日漸興起，呈現三峽榮景。如今，踏入古樸的三峽老街，就像走進了時光隧道，綿延的紅磚拱廊與巴洛克式牌樓，形成老街獨特意象。"
        5 -> "臺中國家歌劇院是位於臺灣臺中市西屯區七期重劃區裡的大型公有展演空間，為日本建築師伊東豊雄設計，佔地57,685平方公尺。歌劇院內擁有大劇院、中劇院、小劇場以及一個小型戶外劇場，另有餐飲空間與空中花園。"
        6 -> "安平古堡，原稱奧蘭治城、熱蘭遮堡或熱蘭遮城，又名臺灣城、安平鎮城、安平城、王城、紅毛城、赤嵌城，是一座位於臺灣臺南市安平區的一個城郭遺址。於1623年10月由荷蘭東印度公司興建簡易城砦，1624年4月底拆毀，8月底原址重建堡壘，至1634年竣工，是臺灣最早的要塞建築。自建城以來，曾是荷蘭及明鄭統治臺灣的中樞，"
        7 -> "高雄85大樓，前稱東帝士85國際廣場、東帝士建台大樓、TC Tower，位於高雄市苓雅區，緊鄰著高雄港和新光碼頭，是85層樓高的摩天大樓，結構高度為347.5公尺，加上天線為378公尺，目前為高雄第一高樓、台灣第二高的摩天大樓。1997年完工時，為僅次於中信廣場、信興廣場的亞洲第三高樓。"
        8 -> "日月潭，是一個位在臺灣南投縣魚池鄉日月村的半天然淡水湖泊兼水力發電用水庫；該潭是臺灣本島面積第二大的湖泊及第一大半天然湖泊兼發電用水庫。該潭平均水面海拔約736公尺，常態面積約7.93平方公里，最高水深達27公尺。其蘊含自然生態豐富，但其中有非常多是外來種生物。"
        9 -> "鵝鑾鼻燈塔是一座位於臺灣屏東縣恆春鎮墾丁國家公園鵝鑾鼻的燈塔。該燈塔一度被認定為台灣最南端的標誌也是照射距離最遠的燈塔，後被台灣最南點地標取代。最初落成於清治1883年，至1895年被毀，後於日治1898年再次建立，1962年中華民國政府再重修改建其燈具設施，2024年3月15日登錄為國定古蹟。"
        10 -> "白沙灣是墾丁相當受歡迎的海灘之一，這裡的海灣綿長，海水清澈，沙灘中的貝殼沙含量高，沙子潔白細緻，故得此名。這裡有不少水上活動可以玩，是刺激的香蕉船、水上摩托車……等等，同時也有租借浮板與泳圈的服務，如果你喜歡潛水，這裡海底豐富的生態更是你不能錯過的。由於恰好位於西邊，日落時分夕陽的餘輝映照在海面上的景象也相當迷人，就算什麼事也不做，躺在沙灘上悠閒地欣賞海景，也實在是人生一大樂事。"
        else -> " "
    }
}


@Preview(showBackground = true)
@Composable
fun AppPreview() {
    val navController = rememberNavController()
    MyApp(navController = navController)
}