package com.example.myapplication.ui.theme

import androidx.compose.ui.graphics.Color

val Red100 = Color(0xffff0000)
val Red80 = Color(0xffff5151)
val Red20 = Color(0xeee88a8a)

val Yellow100 = Color(0xffffa600)
val Yellow80 = Color(0xeeeaaa31)
val Yellow20 = Color(0xeeeac47c)